/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;
import com.entity.Cart;
import java.sql.ResultSet;
import java.util.ArrayList;

/**
 *
 * @author ADMIN
 */
public class CartDAOImpl implements CartDAO{
    private Connection conn;
    
    public CartDAOImpl(Connection conn){
        super();
        this.conn=conn;
    }
    
    @Override
    public List<Cart> getBookByUser(int userId) {
        List<Cart> list = new ArrayList<>();
        Cart c=null;
        double totalPrice=0;
        try{
            String sql = "select * from cart where uid=?";
            PreparedStatement ps= conn.prepareStatement(sql);
            ps.setInt(1, userId);
            
            ResultSet rs=ps.executeQuery();
            
            while(rs.next()){
                c=new Cart();
                c.setCid(rs.getInt(1));
                c.setBid(rs.getInt(2));
                c.setUserId(rs.getInt(3));
                c.setBookName(rs.getString(4));
                c.setAuthor(rs.getString(5));
                c.setPrice(rs.getDouble(6));
                totalPrice=totalPrice+rs.getDouble(7);
                c.setTotalPrice(totalPrice);
                list.add(c);
            }
            
        }catch(Exception e){
            e.printStackTrace();
        }
        return list;
    }
    
    @Override
    public boolean deleteBook(int bid, int uid, int cid) {
        boolean f=false;
        try{
            String sql="delete from cart where bid=? and uid=? and cid=?";
            PreparedStatement ps=conn.prepareStatement(sql);
            ps.setInt(1, bid);
            ps.setInt(2, uid);
            ps.setInt(3, cid);
            int i=ps.executeUpdate();
            if(i==1){
                f=true;
            }
        }catch(SQLException e){
            e.printStackTrace();
        }
        return f;
    }

    @Override
    public boolean deleteCarts(int uid) {
        boolean f=false;
        try{
            String sql="delete from cart where uid=?";
            PreparedStatement ps=conn.prepareStatement(sql);
            ps.setInt(1, uid);
            int i=ps.executeUpdate();
            if(i>=1){
                f=true;
            }
        }catch(SQLException e){
            e.printStackTrace();
        }
        return f;
    }
    
}
